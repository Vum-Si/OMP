import argparse
import ipaddress

def is_in_existing_range_or_cidr_pool(ip, ranges):
    ip_obj = ipaddress.IPv4Address(ip)
    for range_or_cidr in ranges:
        if '-' in range_or_cidr:  # It's a range
            start_ip, end_ip = range_or_cidr.split('-')
            if ip_obj >= ipaddress.IPv4Address(start_ip) and ip_obj <= ipaddress.IPv4Address(end_ip):
                return True
        else:  # It's a CIDR block
            cidr_obj = ipaddress.IPv4Network(range_or_cidr, strict=False)
            if ip_obj in cidr_obj:
                return True
    return False


def ip_range(start_ip, end_ip):
    start = ipaddress.IPv4Address(start_ip)
    end = ipaddress.IPv4Address(end_ip)
    return [str(ip) for ip in ipaddress.summarize_address_range(start, end)]

# 源 IP 处理方法
def condense_ip_addresses(ip_list):
    # ip CIDR 地址池
    ranges_and_cidrs = [ip for ip in ip_list if '/' in ip or '-' in ip]

    # Process individual IPs and ranges
    condensed_ips = []
    sorted_ips = sorted(ip_list, key=lambda ip: ipaddress.IPv4Address(ip.split('/')[0].split('-')[0]))

    i = 0
    while i < len(sorted_ips):
        ip = sorted_ips[i]
        if '/' in ip or '-' in ip:
            condensed_ips.append(ip)
        else:
            if not is_in_existing_range_or_cidr_pool(ip, ranges_and_cidrs):
                start_ip = ip
                while i + 1 < len(sorted_ips) and '-' not in sorted_ips[i + 1] and '/' not in sorted_ips[i + 1] and \
                        ipaddress.IPv4Address(sorted_ips[i + 1]) == ipaddress.IPv4Address(ip) + 1:
                    i += 1
                    ip = sorted_ips[i]
                end_ip = ip
                if start_ip == end_ip:
                    condensed_ips.append(start_ip)
                else:
                    condensed_ips.append(f"{start_ip}-{end_ip}")
        i += 1

    return condensed_ips
def generate_iptables_rules(action, protocol, ports, sources):
    rules = []
    # 端口列表
    port_ranges = []
    ports = sorted(ports)
    i = 0
    while i < len(ports):
        start_port = ports[i]
        while i + 1 < len(ports) and ports[i + 1] == ports[i] + 1:
            i += 1
        end_port = ports[i]
        port_ranges.append((start_port, end_port))
        i += 1

    # 生成 iptables 规则
    for port in port_ranges:
        if len(sources) == 0:
            rule = generate_rule(action, protocol, port, sources)
            rules.append(rule)
        else:
            for i in range(len(sources)):
                rule = generate_rule(action, protocol, port, sources[i])
                rules.append(rule)

    return rules

# 生成单个 iptables 规则
def generate_rule(action, protocol, port, source_ip):
    start_port, end_port = port
    if len(source_ip) == 0:
        if action == "allow":
            rule = f"iptables -I INPUT -p {protocol} --match multiport --dports " + \
                   ','.join(
                       [f"{start_port}-{end_port}" if start_port != end_port else str(start_port)])
            rule += " -j ACCEPT"
        elif action == "deny":
            rule = f"iptables -A INPUT -p {protocol} --match multiport --dports " + \
                   ','.join(
                       [f"{start_port}-{end_port}" if start_port != end_port else str(start_port)])
            rule += " -j DROP"
        else:
            raise ValueError("Invalid action. Use 'allow' or 'deny'.")
        return rule
    else:
        if "/" in source_ip:
            if action == "allow":
                rule = f"iptables -I INPUT -p {protocol} --match multiport --dports " + \
                       ','.join([f"{start_port}-{end_port}" if start_port != end_port else str(start_port)]) + \
                       f" -s {source_ip}"
                rule += " -j ACCEPT"
            elif action == "deny":
                rule = f"iptables -A INPUT -p {protocol} --match multiport --dports " + \
                       ','.join([f"{start_port}-{end_port}" if start_port != end_port else str(start_port)]) + \
                       f" -s {source_ip}"
                rule += " -j DROP"
            else:
                raise ValueError("Invalid action. Use 'allow' or 'deny'.")
            return rule
        else:
            rule = f"iptables -I INPUT -p {protocol} --match multiport --dports " + \
                   ','.join([f"{start_port}-{end_port}" if start_port != end_port else str(start_port)]) + \
                   f" -m iprange --src-range {source_ip}"
            if action == "allow":
                rule += " -j ACCEPT"
            elif action == "deny":
                rule += " -j DROP"
            else:
                raise ValueError("Invalid action. Use 'allow' or 'deny'.")
            return rule


def main():
    parser = argparse.ArgumentParser(description="Generate iptables rules.")
    parser.add_argument("--action","-action", choices=["allow", "deny"], help="网络动作: allow or deny")
    parser.add_argument("--protocol", "-protocol", choices=["tcp", "udp"], help="协议: tcp or udp")
    parser.add_argument("--ports", "-ports",nargs="+", help="端口列表: (e.g., 18080 18081 18082)")
    parser.add_argument("--ip", "-ip", nargs="+", help="不重要参数，omp 强行注入")
    parser.add_argument("--source", "-source", nargs="+",
                        help="源 IP 地址或者源 IP 网段:(e.g., 192.168.1.1 192.168.1.2 192.168.1.3 192.168.1.10)")

    args = parser.parse_args()

    if args.source is None:
        condensed_ips = []
    else:
        ip_list = [ip for ip in args.source]
        condensed_ips = condense_ip_addresses(ip_list)

    # 处理端口范围
    ports = []
    for port in args.ports:
        if "-" in port:
            start_port, end_port = map(int, port.split("-"))
            ports.extend(range(start_port, end_port + 1))
        else:
            ports.append(int(port))

    rules = generate_iptables_rules(args.action, args.protocol, ports, condensed_ips)

    # 输出规则
    print("\n----iptables----")
    for rule in rules:
        print(rule)
    print("----iptables----\n")

if __name__ == "__main__":
    main()
