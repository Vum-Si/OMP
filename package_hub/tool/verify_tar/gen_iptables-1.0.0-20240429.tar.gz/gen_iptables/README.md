# iptables 规则生成工具

**制作人**：whale.liu

## 场景描述

客户侧进行黑盒扫描的时候，发现我们端口存在漏洞时，我们通过对端口添加 iptables规则，禁止特定外部访问，允许我们自己的机器互相访问，这样增加主机安全性，同时也减少我们的工作量。

**注意：**
**本工具只在界面生成 iptables规则，需要客户自行添加到服务器上执行，工具并不会将直接添加到服务器上。**

本工具用于生成 iptables规则，支持生成如下规则：
1. 允许/拒绝所有流量
2. 允许/拒绝指定IP地址的流量
3. 允许/拒绝指定端口的流量

## 1.依赖：

- Python环境：Python 3.6+

## 2.参数解释：

|    参数    | 要求 |                   参数说明                    |
|:--------:|:--:|:-----------------------------------------:|
|  action  | 必选 |        允许/拒绝：allow/deny，默认为 allow         |
| protocol | 必选 |            协议：tcp/udp，默认为 tcp             |
|   port   | 必选 | 主机端口号，可以写单个，也可以写连续的端口号，如 80,443,8080-8090 |
|  source  | 可选 |    源IP地址，支持CIDR格式，支持多个源IP地址，支持 IP 地址段     |


port 写法支持，一条命令行，可同时存在多个格式
- 单个端口号：18080
- 多个端口号：18080,18081,19000,18088
- 连续端口号：18080-18082


source 写法支持，一条命令行，可同时存在多个格式
- 单个IP地址：192.168.1.1
- 多个IP地址：192.168.1.1,192.168.1.2,192.168.1.3
- IP地址段：192.168.1.1-192.168.1.10
- CIDR格式：192.168.1.0/24


## 3.使用方法：

使用思路： 一般第一步先对端口做指定 IP 的允许，然后对端口做整体的拒绝。
因为 iptables 从上至下依次匹配，所以先允许后拒绝，不会中断连接。

```shell
# 只允许 10.0.20.69 和其所在网段访问，以下三种任选其一即可
~: python gen_iptables.py  --action allow --protocol tcp --ports 81 --source 10.0.20.69
----iptables----
iptables -I INPUT -p tcp --match multiport --dports 80-82 -m iprange --src-range 10.0.20.1-10.0.20.100 -j ACCEPT
iptables -I INPUT -p tcp --match multiport --dports 80-82 -s 10.0.30.0/24 -j ACCEPT
iptables -I INPUT -p tcp --match multiport --dports 18080-19000 -m iprange --src-range 10.0.20.1-10.0.20.100 -j ACCEPT
iptables -I INPUT -p tcp --match multiport --dports 18080-19000 -s 10.0.30.0/24 -j ACCEPT
----iptables----

# 拒绝 81 端口的流量
~: python gen_iptables.py  --action deny --protocol tcp --ports 81
----iptables----
iptables -A INPUT -p tcp --match multiport --dports 81 -j DROP
----iptables----
```

端口拒绝，通过 nmap 扫描，可以发现由 open 状态变为 filtered

端口允许，通过 nmap 扫描，可以发现由 filtered 状态变为 open
