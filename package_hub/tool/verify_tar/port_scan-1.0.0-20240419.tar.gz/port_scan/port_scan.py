import argparse
import socket


def scan_port(ip, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((ip, port))
        if result == 0:
            print(f"Port {port} is open")
            return f"Port {port} is open"
        sock.close()
    except KeyboardInterrupt:
        print("Keyboard Interrupt")
        exit()
    except socket.error:
        print("Couldn't connect to server")


def main():
    parser = argparse.ArgumentParser(description="Simple port scanner")
    parser.add_argument("--ipList", "-ipList", dest="ipList", required=True, help="IP address to scan")
    parser.add_argument("--ports", "-ports", dest="ports", required=True,
                        help="Port or port range to scan (e.g., 80 or 1-100)")
    parser.add_argument("--ip", "-ip", nargs="+", help="不重要参数，omp 强行注入")
    args = parser.parse_args()

    print("\n----端口扫描----")
    ip = args.ipList
    port_input = args.ports.split("-")
    if len(port_input) == 1:
        start_port = end_port = int(port_input[0])
    elif len(port_input) == 2:
        start_port = int(port_input[0])
        end_port = int(port_input[1])
    else:
        print("Invalid port range")
        exit()

    for port in range(start_port, end_port + 1):
        scan_port(ip, port)
    print("----端口扫描----\n")


if __name__ == "__main__":
    main()
